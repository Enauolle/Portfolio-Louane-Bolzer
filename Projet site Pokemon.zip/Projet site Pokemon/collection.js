let collectionData = [
    {
        collection_id: 1,
        pokemon_id: 2,
        pokemon_nickname: "Plante Chelou"
    },
    {
        collection_id: 2,
        pokemon_id: 2,
        pokemon_nickname: "Patate"
    },
    {
        collection_id: 5433,
        pokemon_id: 2,
        pokemon_nickname: "Pamplemousse"
    },
    {
        collection_id: 3,
        pokemon_id: 45,
        pokemon_nickname: "J'ai pas d'idées"
    },
    {
        collection_id: 4,
        pokemon_id: 101,
        pokemon_nickname: "Truc"
    }
]