function getPokemonById(domElementId, id, pokemonData) {
    // Affiche un Pokémon par son ID dans l'élément domElementId
    const domElement = document.getElementById(domElementId);
    const pokemon = pokemonData[id];
    if (!pokemon) {
        domElement.innerHTML = "<p>Pokémon non trouvé.</p>";
        return;
    }
    domElement.innerHTML = `
        <div class="carte">
            <p>${id} - ${pokemon.name.fr}</p>
            <img src="img/96px/${id}.png" />
            <p>${pokemon.type_fr}</p>
            <div class="ajouter">
                <button onclick="addPokemonToCollection('collect', '${id}', pokemonData)">Ajouter à ma collection</button>
            </div>
        </div>
    `;
}

function getPokemonIdByName(name, pokemonData) {
    for (let key in pokemonData) {
        if (name === pokemonData[key]["identifier"]) {
            return key;
        }
    }
    return null;
}

function listAllPokemon(domElementId, pokemonData) {
    const domElement = document.getElementById(domElementId);
    domElement.innerHTML = Object.values(pokemonData).map(pokemon => `
        <div class="carte">
            <p>${getPokemonIdByName(pokemon.identifier, pokemonData)} - ${pokemon.name.fr}</p>
            <img src="img/96px/${getPokemonIdByName(pokemon.identifier, pokemonData)}.png" />
            <p>${pokemon.type_fr}</p>
            <div class="ajouter">
                <button onclick="addPokemonToCollection('${getPokemonIdByName(pokemon.identifier, pokemonData)}', pokemonData)">Ajouter à ma collection</button>
            </div>
        </div>
    `).join('');
}

function createPokemonDropdown(domElementId, pokemonData) {
    const domElement = document.getElementById(domElementId);

    const selectElement = document.createElement('select');
    selectElement.id = 'pokemonDropdown';

    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Sélectionner un pokemon';
    selectElement.appendChild(defaultOption);

    Object.values(pokemonData).forEach(pokemon => {
        const option = document.createElement('option');
        option.value = pokemon.identifier;
        option.textContent = pokemon.identifier.charAt(0).toUpperCase() + pokemon.identifier.slice(1);
        selectElement.appendChild(option);
    });

    domElement.appendChild(selectElement);
}

function listPokemonDetail(domElementId, pokemonData) {
    const params = new URLSearchParams(document.location.search);
    const pokName = params.get("pokemonName");
    const pokId = getPokemonIdByName(pokName, pokemonData);
    if (!pokId) {
        document.getElementById(domElementId).innerHTML = "<p>Pokémon non trouvé.</p>";
        return;
    }
    const pokemon = pokemonData[pokId];
    const domElement = document.getElementById(domElementId);
    domElement.innerHTML = `
        <a href="collectionperso.html"><box class="retour">Retour</box></a>
        <div class="bigcard" id="carte">
            <h2>${pokemon.name.fr}</h2>
            <div class="photo">
                <img src="/img/96px/${pokId}.png" class="pokepoke"/>
            </div>
            <h5>Type</h5>
            <div class="type" style="background-color: ${pokemon.type_color[0]};"><h4>${pokemon.type_fr[0]}</h4></div>
            <div class="type2" style="background-color: ${pokemon.type_color[1] || '#fff'};"><h4>${pokemon.type_fr[1] || ''}</h4></div>
            <h5 class="stat">Statistique</h5>
            <div class="sat">
                <div class="écriture">
                    <p>PV : ${pokemon.stats.hp}</p>
                    <p>Attaque : ${pokemon.stats.attack}</p>
                    <p>Défense : ${pokemon.stats.defense}</p>
                    <p>Attaque Spéciale : ${pokemon.stats.special_attack}</p>
                    <p>Défense Spéciale : ${pokemon.stats.special_defense}</p>
                    <p>Vitesse : ${pokemon.stats.speed}</p>
                </div>
            </div>
        </div>
    `;
}

function listAllPokemonFromCollection(domElementId, collectionData, pokemonData) {
    const domElement = document.getElementById(domElementId);
    domElement.innerHTML = collectionData.map(entry => {
        const pokemon = pokemonData[entry.pokemon_id];
        if (!pokemon) return '';
        return `
            <div class="carte" id="card-${entry.collection_id}">
                <a href="creature.html?pokemonName=${pokemon.identifier}">
                <img src="img/96px/${entry.pokemon_id}.png"/>
            </a>
                <p>${pokemon.type_fr}</p>
                <p>Surnom: ${entry.pokemon_nickname}</p>
                <div class="ajouter">
                    <button class="supp_button" onclick="removeCardFromCollection(${entry.collection_id})">Supprimer</button>
                </div>
            </div>
        `;
    }).join('');
}

function removeCardFromPage(collectionId) {
    const card = document.getElementById(`card-${collectionId}`);
    if (card) {
        card.remove();
    }
}

function changePokemonNickname(domElementId, newNickname) {
    const domElement = document.getElementById(domElementId);
    domElement.innerHTML = `<p>Surnom du pokemon modifié en ${newNickname}</p>`;
}

function addPokemonToCollection(pokemonId, pokemonData) {
    // Récupérer la collection depuis localStorage (ou créer tableau vide)
    let collection = JSON.parse(localStorage.getItem('collectionData')) || [];

    // Créer un nouvel id unique (timestamp)
    const newCollectionId = Date.now();

    // Ajouter le Pokémon à la collection
    collection.push({
        collection_id: newCollectionId,
        pokemon_id: pokemonId,
        pokemon_nickname: "-----"
    });

    // Sauvegarder dans localStorage
    localStorage.setItem('collectionData', JSON.stringify(collection));

    alert(`Le Pokémon ${pokemonData[pokemonId].name.fr} a été ajouté à votre collection.`);
}


    domElement.appendChild(pokemonElement);

function removeCardFromCollection(collectionId) {
    removeCardFromPage(collectionId);
    const index = collectionData.findIndex(entry => entry.collection_id === collectionId);
    if (index !== -1) {
        collectionData.splice(index, 1);
    }
}
